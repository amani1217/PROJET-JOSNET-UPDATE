declare module '@splidejs/react-splide';
declare module 'nprogress';
declare module 'next-intl';