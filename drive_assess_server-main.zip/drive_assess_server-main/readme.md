Drive assessment server
