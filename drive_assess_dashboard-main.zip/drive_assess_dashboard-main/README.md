Drive assessment dashboard for admins
